---
title: "About the Course"
date: 2019-03-08T15:09:59+01:00
draft: false
image: "techclass.jpeg"
tags: [
"Course"
]
---
 Tech, Data & Innovation gives you the power, knowledge and tools you need to dive into the new world of technology. This website exists to serve the current students and alumni fully capitalize on the knowledge and resources imparted on us by Professor Mazars any time, any where. Ride the wave or drown.
