---
title: "Meet the Professor"
date: 2019-03-08T15:09:51+01:00
draft: false
image: "prof.jpeg"
tags: ["course"]
---
# Meet the man behind the vision.

Ghislain Mazars is both a past student and current professor at HEC Paris. He has been involved in a myriad of tech endeavors, including his current position as Founder and CEO of Ubeeko, where he focuses on Machine Learning engineering projects. Professor Mazars offers a unique look into the tech industries most important topics, including discussions on open source, big data, and the cloud.


[Prof Mazars' LinkedIn] (https://www.linkedin.com/in/ghislainmazars/?originalSubdomain=fr)
